using System;
using System.Linq;

class MainClass {
  public static void Main(string[] args) {

    //asking user input for a password
    Console.WriteLine("Enter a password \n it should be of 8 characters in length and contain at least one uppercase; one lowercase; one number; one special character; and no more than 3 consecutive characters ");
    string password = Console.ReadLine();

    bool[] fail = new bool[5];

    //assigning a bool value for each check
    fail[0] = HasLower(password);
    fail[1] = HasUpper(password);
    fail[2] = HasDigits(password);
    fail[3] = SpecialChars(password);
    fail[4] = ConsecutiveChars(password);

    // if any of the checks returned false the password input is not correct
    if (!fail.All(x =>x)) {
      Console.WriteLine($ "Lower Case: {fail[0]}");
      Console.WriteLine($ "Upper Case: {fail[1]}");
      Console.WriteLine($ "Number/s Included: {fail[2]}");
      Console.WriteLine($ "Special Character/s Included: {fail[3]}");
      Console.WriteLine($ "Consecutive Characters: {fail[4]}");
    }
    // otherwise the password is correct
    else {
      Console.WriteLine("Password True!");
    }
  }
  //looping through the string and returning true if the string contains lower case characters
  public static bool HasLower(string lowerCase) {
    for (int i = 0; i < lowerCase.Length; i++) {
      if (lowerCase[i] >= 'a' && lowerCase[i] <= 'z') {
        return true;
      }
    }
    return false;
  }
  //looping through the string and returning true if the string contains upper case characters
  public static bool HasUpper(string upperCase) {
    for (int i = 0; i < upperCase.Length; i++) {
      if (upperCase[i] >= 'A' && upperCase[i] <= 'Z') {
        return true;
      }
    }
    return false;
  }
  //looping through the string and returning true if the string contains any numbers
  public static bool HasDigits(string digits) {
    for (int i = 0; i < digits.Length; i++) {
      if (digits[i] >= '0' && digits[i] <= '9') {
        return true;
      }
    }
    return false;
  }
  //looping through the string and returning true if the string contains any of the listed special characters
  public static bool SpecialChars(string special) {
    char[] specialChars = {'!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '=', '[', '{', ']', '}', ';', ':', '<', '>', '|', '.', '/', '?', ',', '-'};

    for (int i = 0; i < special.Length; i++) {
      if (specialChars.Contains(special[i])) {
        return true;
      }
    }
    return false;
  }
  //looping through the string and returning true if the string contains 3  or more consecutive characters
  public static bool ConsecutiveChars(string consecChars) {
    for (int i = 0; i < consecChars.Length - 2; i++) {
      if (consecChars[i] == consecChars[i + 1] && consecChars[i] == consecChars[i + 2]) {
        return false;
      }
    }
    return true;
  }
}