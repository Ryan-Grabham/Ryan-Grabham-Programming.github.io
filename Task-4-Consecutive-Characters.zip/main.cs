using System;
using System.Linq;
using System.Collections.Generic;

class MainClass {
  public static void Main(string[] args) {
    string S = "XXXYXYXXYYYXYYYYXX";
    int count = 0;

    //creating a new string type list
    List < string > consecutiveChars = new List < string > ();

    //loops throughevery character in the string
    for (int i = 0; i < S.Length - 1; i++) {
      //if the current character and current character are not equal:
      if (S[i + 1] != S[i]) {
        //add a snew string with length "count+1" and the value of the character
        consecutiveChars.Add(new string(S[i], count + 1));
        //reset the counter, to continue the loop
        count = 0;
      }
      else {
        count++;
      }
    }
    //orders the string list descending order and gets the first item
    string longestConsec = consecutiveChars.OrderByDescending(i =>i.Length).First();
    Console.WriteLine($"The length of the longest consecutive substring is: {longestConsec.Length}");
    Console.WriteLine($"The repeated value is: {longestConsec}");
  }
}