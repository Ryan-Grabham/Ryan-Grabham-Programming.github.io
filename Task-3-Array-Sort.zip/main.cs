using System;
using System.Collections.Generic;
using System.Linq;

class MainClass {
  public static void Main(string[] args) {

    int[] arr = new int[] {9, 88, 1, 9, 88, 87, 35, 12, 50, 23, 12, 1, 4, 9};

    //sort the array, in descending order
    int[] sort = arr.OrderByDescending(i =>i).ToArray();

    // ArrayList that will contain the unique values from the first array
    var noRepeat = new System.Collections.ArrayList();

    //go through each item in sort array
    foreach(var item in sort) {
      //if the noRepeat array doesn't contain the item from sort, then add it
      if (!noRepeat.Contains(item)) noRepeat.Add(item);
    }
    //print out the values of noRepeat, line by line
    foreach(int number in noRepeat) {
      Console.WriteLine(number);
    }
  }
}