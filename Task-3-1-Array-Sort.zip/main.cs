using System;
using System.Linq;

class MainClass {
  public static void Main(string[] args) {
    int[] arr = {9, 88, 1, 9, 88, 87, 35, 12, 50, 23, 12, 1, 4, 9};
    //removing any repeat values
    int[] noRepeat = arr.Distinct().ToArray();

    Array.Sort(noRepeat);
    Array.Reverse(noRepeat);
    //print out array values, line by line
    Array.ForEach < int > (noRepeat, n =>Console.WriteLine(n));
  }
}