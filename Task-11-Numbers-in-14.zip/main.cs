using System;
using System.Linq;
using System.Collections.Generic;

class MainClass {
  public static void Main(string[] args) {

    int[] A = {3, 5, 2, 1, 7, 4};
    int T = 0;

    //Sorting the array, using bubble sort method  
    for (int p = 0; p <= A.Length - 2; p++) {
      for (int i = 0; i <= A.Length - 2; i++) {
        if (A[i] > A[i + 1]) {
          T = A[i + 1];
          A[i + 1] = A[i];
          A[i] = T;
        }
      }
    }

    T = 0;
    int c = 0;

    //loop through each value in   
    for (int i = 0; i < A.Length; i++) {
      // T value is less than 14 then, 
      if (T < 14) {
        // plus the A value to T
        T += A[i];
        // plus one to c
        c++;
      }
      // if T > 14, 
      else {
        //remove the previously added value, in this case 5
        T -= A[i - 1];
        //subtract 1 from c 
        c--;
      }
    }

    Console.WriteLine($ "The highest amount you can make is {T}");
    Console.WriteLine($ "The maximum number of integers you can combine is {c}");
  }
}