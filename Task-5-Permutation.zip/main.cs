using System;

class MainClass {
  public static void Main(string[] args) {
    string S = "ABC";

    //using each method and the base S string to output each permutation
    Console.WriteLine(Combination1(S));
    Console.WriteLine(Combination2(S));
    Console.WriteLine(Combination3(S));
    Console.WriteLine(Combination4(S));
    Console.WriteLine(Combination5(S));
    Console.WriteLine(Combination6(S));
  }

  public static string Combination1(string sequence) {
    //new string making the 1st character (A) the holding value
    string A = sequence[0].ToString();
    //adding the other two values to a new string in a specific order
    string firstString = sequence[1].ToString() + sequence[2].ToString();
    //returning the two strings together
    return A + firstString;
  }

  public static string Combination2(string sequence) {
    //new string making the 1st character (A) the holding value
    string A = sequence[0].ToString();
    //adding the other two values to a new string in a specific order
    string secondString = sequence[2].ToString() + sequence[1].ToString();
    //returning the two strings together
    return A + secondString;
  }

  public static string Combination3(string sequence) {
    //new string making the 2nd character (B) the holding value
    string B = sequence[1].ToString();
    //adding the other two values to a new string in a specific order
    string thirdString = sequence[0].ToString() + sequence[2].ToString();
    //returning the two strings together
    return B + thirdString;
  }

  public static string Combination4(string sequence) {
    //new string making the 2nd character (B) the holding value
    string B = sequence[1].ToString();
    //adding the other two values to a new string in a specific order
    string fourthString = sequence[2].ToString() + sequence[0].ToString();
    //returning the two strings together
    return B + fourthString;
  }

  public static string Combination5(string sequence) {
    //new string making the 3rd character (C) the holding value
    string C = sequence[2].ToString();
    //adding the other two values to a new string in a specific order
    string fifthString = sequence[0].ToString() + sequence[1].ToString();
    //returning the two strings together
    return C + fifthString;
  }
  
  public static string Combination6(string sequence) {
    //new string making the 3rd character (C) the holding value
    string C = sequence[2].ToString();
    //adding the other two values to a new string in a specific order
    string sixthString = sequence[1].ToString() + sequence[0].ToString();
    //returning the two strings together
    return C + sixthString;
  }
}