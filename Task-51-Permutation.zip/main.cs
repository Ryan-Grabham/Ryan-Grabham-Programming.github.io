using System;
using System.Collections.Generic;

class MainClass {
  public static void Main (string[] args) {
    
  
    string baseString = "ABC";

    var permutations = Combinations(baseString);

    //printing each permutation line by line
    foreach(string permutation in permutations){
      Console.WriteLine(permutation);
    }

  }

  public static List<string> Combinations(string S){
   
    //creating a new list
    List<string> permutations = new List<string>();

    //if length of S is less than two, then add it to the list
    if (S.Length < 2) {
      permutations.Add(S);
      
      //returning the list
      return permutations;
    }

    //looping through S to find the location of every character that is not the first in the string
    for (int i = 0; i < S.Length; i++ ){
      //declares the held character as the current character in the string
      char character = S[i];
      if (S.IndexOf(character) != i) {
        continue;
      }

      // Creates a new string using the substring of lastString starting at 0 until the value of i, as well as the substring from i + 1 to the end of the string.
      string remainder = S.Substring(0, i) + S.Substring(i + 1);

      //adding the remainders to the held character
      foreach (string permutation in Combinations(remainder)) {
        permutations.Add(character + permutation);
      }
    }
    
    return permutations;
  }
}