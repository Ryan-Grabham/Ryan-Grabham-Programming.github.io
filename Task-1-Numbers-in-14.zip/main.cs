using System;

class MainClass {
  public static void Main(string[] args) {

    int[] A = {3, 5, 2, 1, 7, 4};
    int T = 0;
    int temp = 0;
    int c = 0;

    Array.Sort(A);

    //Looping through each value in A  
    for (int i = 0; i < A.Length; i++) {
      //Add value to temp   
      temp += A[i];

      //stop if T value = more than 14  
      if (temp > 14) {
        break;
      }
      //otherwise, keep adding the values  
      else {
        T += A[i];
        c++;
      }
    }

    Console.WriteLine($"The highest amount you can make is {T}");
    Console.WriteLine($"The maximum number of integers you can combine is {c}");
  }
}