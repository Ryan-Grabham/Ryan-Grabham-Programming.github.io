using System;
using System.Linq;
using System.Collections.Generic;

class MainClass {
  public static void Main(string[] args) {
    bool charCheck = false;
    bool upperChars = false;
    bool lowerChars = false;
    bool anyNumbers = false;
    bool specialChars = false;
    bool consecChars = false;

    //asking user input for a password
    Console.WriteLine("Enter a password \n it should be of 8 characters in length and contain at least one uppercase; one lowercase; one number; one special character; and no more than 3 consecutive characters ");
    string password = Console.ReadLine();

    //checking if password is longer than 7 characters
    if (password.Length > 7) {
      charCheck = true;
    }

    //checking for uppercase characters
    if (password.Any(char.IsUpper)) {
      upperChars = true;
    }

    //checking for lowercase characters
    if (password.Any(char.IsLower)) {
      lowerChars = true;
    }

    //checking for numbers
    if (password.Any(char.IsDigit)) {
      anyNumbers = true;
    }

    //checking for special characters
    if (password.Any(char.IsPunctuation)) {
      specialChars = true;
    }

    //checking that there is no consecutive characters
    for (int i = 0; i < password.Length - 2; i++) {
      if (password[i] == password[i + 1] && password[i] == password[i + 2]) consecChars = true;
    }

    // if all criteria is met, output true
    if (charCheck && upperChars && lowerChars && anyNumbers && specialChars && !consecChars) {
      Console.WriteLine("True");
    }

    //if criteria isn't met, output what is wrong
    if (!charCheck) {
      Console.WriteLine("False");
      Console.WriteLine("Password is shorter than 7 characters");
    }

    if (!upperChars) {
      Console.WriteLine("False");
      Console.WriteLine("Password should contain at least one uppercase character");
    }

    if (!lowerChars) {
      Console.WriteLine("False");
      Console.WriteLine("Password should contain at least one lowercase character");
    }
    if (!anyNumbers) {
      Console.WriteLine("False");
      Console.WriteLine("Password should contain at least one number");
    }
    if (!specialChars) {
      Console.WriteLine("False");
      Console.WriteLine("Password should contain at least one special character");
    }
    if (consecChars) {
      Console.WriteLine("False");
      Console.WriteLine("Password contains three or more consecutive characters");
    }
  }
}