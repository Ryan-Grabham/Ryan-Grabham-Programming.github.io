using System;
using System.Linq;
using System.Collections.Generic;

class MainClass {
  public static void Main(string[] args) {
    string S = "XXXYXYXXYYYXYYYYXX";

    //create a string type list
    List < string > consecutiveChars = new List < string > ();

    //count how many times x and y appear
    int xCount = 0;
    int yCount = 0;

    //loops through each character in the string
    foreach(char character in S) {
      //if the character isn't Y:     
      if (character != 'Y') {
        //adds a new string to consecutiveChars with Y as a value
        consecutiveChars.Add(new string('Y', yCount));

        //adds 1 to xCount and  sets the yCount back to 0.
        xCount++;
        yCount = 0;
      }
      //if the character is a Y: 
      else {
        //adds a new string to consecutiveChars with X as a value
        consecutiveChars.Add(new string('X', xCount));
        //adds 1 to the yCount and sets the xCount back to 0.
        yCount++;
        xCount = 0;
      }
    }
    //orders the string list in descending order and gets the first item
    string longestConsec = consecutiveChars.OrderByDescending(x =>x.Length).First();
    Console.WriteLine($"The length of the longest consecutive substring is: {longestConsec.Length}");
    Console.WriteLine($"The repeated value is: {longestConsec}");
  }
}